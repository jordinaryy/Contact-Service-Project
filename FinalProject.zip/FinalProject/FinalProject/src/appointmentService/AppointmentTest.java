package appointmentService;


import static org.junit.Assert.*;
import org.junit.Test;
import java.util.Date;
import java.util.Calendar;

public class AppointmentTest {

	
	@Test
    public void testGoodAppointment() {
		//make a date for tomorrow
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1); 
        //make a new appointment
        Appointment appt = new Appointment("abc123", c.getTime(), "Checkup");
        //make sure that the values are save correctly
        assertEquals("abc123", appt.getId());
        assertEquals("Checkup", appt.getNote());
    }
	// will tell me what goes wrong if the ID is missing (null)
    @Test(expected = IllegalArgumentException.class)
    public void testBadId() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        // this should not work because the ID is null
        new Appointment(null, c.getTime(), "Test");
    }
    //Tests to see what happens if the date is in the past
    @Test(expected = IllegalArgumentException.class)
    public void testPastDate() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, -1); 
        
        //Should crash because the date is in the past
        new Appointment("id1", c.getTime(), "Too late");
    }
    	//Tests to see what happens if the description is too long
    @Test(expected = IllegalArgumentException.class)
    public void testTooLongNote() {
        Calendar c = Calendar.getInstance();
        c.add(Calendar.DATE, 1);
        //Should crash because the note is longer than 50 characters 
        new Appointment("id1", c.getTime(), "This note is way too long and should break the rule for the note length, or will it...");
    }
}
	
	

