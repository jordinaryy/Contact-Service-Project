package appointmentService;

import java.util.HashMap;

public class AppointmentService {

	private HashMap<String, Appointment> appointmentList = new HashMap<>();

    // Add a new appointment if it doesn’t already exist
    public void addAppointment(Appointment appt) {
        if (appointmentList.containsKey(appt.getId())) {
            throw new IllegalArgumentException("ID already used");
        }
        appointmentList.put(appt.getId(), appt);
    }

    // Remove an appointment by its ID
    public void deleteAppointment(String id) {
        if (!appointmentList.containsKey(id)) {
            throw new IllegalArgumentException("ID not found");
        }
        appointmentList.remove(id);
    }

    // Get appointment by ID
    public Appointment getAppointment(String id) {
        return appointmentList.get(id);
    }
}
	

