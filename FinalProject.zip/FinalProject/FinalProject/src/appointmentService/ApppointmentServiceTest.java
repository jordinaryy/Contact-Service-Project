package appointmentService;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import java.util.Calendar;


public class ApppointmentServiceTest {

	 private AppointmentService service; //this manages the appointments
	    private Appointment appt; 

	    //runs before every test
	    @Before
	    public void setUp() {
	        service = new AppointmentService();
	        //makes a new date for tomorrow 
	        Calendar c = Calendar.getInstance();
	        c.add(Calendar.DATE, 1); 
	        
	        //creates a new appointment and adds it to the service
	        appt = new Appointment("one", c.getTime(), "Haircut");
	        service.addAppointment(appt);
	    }
	    //test so that we can add and get an appointment 
	    @Test
	    public void testAddAndGet() {
	    	//makes sure the appointment is stored
	        assertEquals("Haircut", service.getAppointment("one").getNote());
	    }
	    //Test by adding a second appointment with the same ID crashes
	    @Test(expected = IllegalArgumentException.class)
	    public void testAddSameId() {
	        service.addAppointment(appt);
	    }
	    //test to delete an appointment
	    @Test
	    public void testDelete() {
	        service.deleteAppointment("one");
	        assertNull(service.getAppointment("one"));
	    }
	    //testing to delete an appointment that doesn't exist 
	    @Test(expected = IllegalArgumentException.class)
	    public void testDeleteNotThere() {
	        service.deleteAppointment("fake");
	    }
	}
	
	
	

