package appointmentService;

import java.util.Date;

public class Appointment {

	// These are the things each appointment has
    private final String id;
    private final Date date;
    private final String note;
	
    
    public Appointment(String id, Date date, String note) {
        // ID can't be null or too long
        if (id == null || id.length() > 10) {
            throw new IllegalArgumentException("ID is not good");
        }

        // Date must not be null or in the past
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("Date is in the past or missing");
        }

        // Note can't be null or too long
        if (note == null || note.length() > 50) {
            throw new IllegalArgumentException("Note is not good");
        }

        // Save values
        this.id = id;
        this.date = date;
        this.note = note;
    }

    // Let other classes see the values
    public String getId() {
        return id;
    }

    public Date getDate() {
        return date;
    }

    public String getNote() {
        return note;
    }
}
	
