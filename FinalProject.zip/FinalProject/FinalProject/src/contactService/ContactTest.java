package contactService;

import org.junit.Test;
import static org.junit.Assert.*;

//This class tests the Contact class to make sure it works as expected
public class ContactTest {

	 //Creating a contact with valid info should succeed
	 @Test
	    public void testCreateContactSuccess() {
	        Contact c = new Contact("001", "Jadin", "Marshall", "1234567890", "123 Main St");
	        assertEquals("Jadin", c.getFirstName());
	        assertEquals("Marshall", c.getLastName());
	    }

	 	//Creating a contact with a phone number that's too short should fail
	    @Test
	    public void testInvalidPhoneTooShort() {
	        try {
	            new Contact("002", "Jacob", "Krueger", "123", "456 Elm St");
	            fail("Expected error for short phone");
	        } catch (IllegalArgumentException e) {
	            
	        }
	    }
	    //Changing the first name should work correctly
	    @Test
	    public void testChangeFirstName() {
	        Contact c = new Contact("003", "Demetrius", "Jones", "9876543210", "789 Oak St");
	        c.setFirstName("Tim");
	        assertEquals("Tim", c.getFirstName());
	    }
	    //Setting the first name to null should throw an error
	    @Test
	    public void testNullFirstNameThrows() {
	        Contact c = new Contact("004", "Alex", "Condon", "9998887777", "321 Pine St");
	        try {
	            c.setFirstName(null);
	            fail("Expected error for null first name");
	        } catch (IllegalArgumentException e) {
	            
	        }
	    }
	}
	
	

