package contactService;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

//This class tests the ContactService (add, delete, update)
public class ContactServiceTest {

	 private ContactService service; // The service being tested
	 private Contact contact; // A sample contact used in each test

	 	// This method runs before every test method
	    @Before 
	    public void setUp() {
	        service = new ContactService(); 
	        contact = new Contact("007", "Jordan", "Krueger", "1231231125", "Lucky st");
	        service.addContact(contact);
	    }
	    // Adding a contact with a duplicate ID should fail
	    @Test 
	    public void testAddDuplicateIdFails() {
	        try {
	            service.addContact(contact);
	            fail("Expected error for duplicate ID");
	        } catch (IllegalArgumentException e) {
	            
	        }
	    }
	    // Deleting a contact should work, but doing it twice should fail
	    @Test
	    public void testDeleteContact() {
	        service.deleteContact("007");
	        try {
	            service.deleteContact("007");
	            fail("Expected error for deleting nonexistent contact");
	        } catch (IllegalArgumentException e) {
	            
	        }
	    }
	    // Updating the phone number should succeed
	    @Test
	    public void testUpdatePhoneSuccess() {
	        service.updatePhone("007", "9998887777");
	        assertEquals("9998887777", contact.getPhone());
	    }
	    // Updating to an invalid phone number should fail
	    @Test
	    public void testUpdateInvalidPhoneFails() {
	        try {
	            service.updatePhone("007", "abc");
	            fail("Expected error for invalid phone");
	        } catch (IllegalArgumentException e) {
	            
	        }
	    }
	    // Updating a contact that doesn't exist should fail
	    @Test
	    public void testUpdateNonexistentContactFails() {
	        try {
	            service.updateAddress("999", "HowdyJo St");
	            fail("Expected error for nonexistent contact");
	        } catch (IllegalArgumentException e) {
	            
	        }
	    }
	}

