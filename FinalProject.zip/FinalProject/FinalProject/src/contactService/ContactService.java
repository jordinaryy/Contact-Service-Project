package contactService;

import java.util.HashMap;

//This class manages all contact objects (add, update, delete)
public class ContactService {


	    // HashMap stores contacts with their ID as the key
	    private HashMap<String, Contact> contacts = new HashMap<>();

	    // Add a new contact
	    public void addContact(Contact contact) {
	        if (contacts.containsKey(contact.getContactId())) {
	            throw new IllegalArgumentException("Contact ID already exists.");
	        }
	        contacts.put(contact.getContactId(), contact);
	    }

	    // Delete a contact by ID
	    public void deleteContact(String contactId) {
	        if (!contacts.containsKey(contactId)) {
	            throw new IllegalArgumentException("Contact not found.");
	        }
	        contacts.remove(contactId);
	    }

	    // Update contact fields
	    public void updateFirstName(String contactId, String newFirstName) {
	        getContact(contactId).setFirstName(newFirstName);
	    }

	    public void updateLastName(String contactId, String newLastName) {
	        getContact(contactId).setLastName(newLastName);
	    }

	    public void updatePhone(String contactId, String newPhone) {
	        getContact(contactId).setPhone(newPhone);
	    }

	    public void updateAddress(String contactId, String newAddress) {
	        getContact(contactId).setAddress(newAddress);
	    }

	    // Helper method to get a contact by ID
	    private Contact getContact(String contactId) {
	        Contact contact = contacts.get(contactId);
	        if (contact == null) {
	            throw new IllegalArgumentException("Contact not found.");
	        }
	        return contact;
	    }
	}

