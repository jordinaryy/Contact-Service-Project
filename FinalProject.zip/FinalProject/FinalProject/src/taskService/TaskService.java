package taskService;

import java.util.HashMap;



public class TaskService {

	 private HashMap<String, Task> tasks = new HashMap<>();

	    public void addTask(Task task) {
	        if (tasks.containsKey(task.getTaskId())) {
	            throw new IllegalArgumentException("Task ID already exists.");
	        }
	        tasks.put(task.getTaskId(), task);
	    }

	    public void deleteTask(String taskId) {
	        // Should check if taskId exists before removing
	        tasks.remove(taskId); // if ID doesn't exist, does nothing 
	    }
	    	//updates the name of the task given with taskid
	    	// will throw an exception if the task does not exist
	    public void updateTaskName(String taskId, String newName) {
	        Task task = tasks.get(taskId);
	        if (task != null) {
	            task.setName(newName);
	        } else {
	            throw new IllegalArgumentException("Task ID not found.");
	        }
	    }
	    	//updates the description of the task given by taskid
	    	// will throw an exception if the task does not exist
	    public void updateTaskDescription(String taskId, String newDescription) {
	        Task task = tasks.get(taskId);
	        if (task != null) {
	            task.setDescription(newDescription);
	        } else {
	            throw new IllegalArgumentException("Task ID not found.");
	        }
	    }
	    	//retrieves and returns the task object for the given taskid
	    //returns null if the task does not exist
	    public Task getTask(String taskId) {
	        return tasks.get(taskId);
	    }
}
