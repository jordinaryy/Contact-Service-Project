package taskService;

import org.junit.Test;
import static org.junit.Assert.*;

public class TaskTest {
	//test to see if the task class behaves correctly
	@Test
    public void testCreateValidTask() {
        Task task = new Task("REBEL001", "Join Rebels", "Meet Leia and sign up to fight the Empire");
        assertEquals("REBEL001", task.getTaskId());
        assertEquals("Join Rebels", task.getName());
        assertEquals("Meet Leia and sign up to fight the Empire", task.getDescription());
    }
	//Creates a Task with NullId(Should fail)
    @Test(expected = IllegalArgumentException.class)
    public void testNullId() {
        new Task(null, "Train", "Train with Yoda on Dagobah");
    }
    //Tries to use a name longer than 20 characters (should fail)
    @Test(expected = IllegalArgumentException.class)
    public void testTooLongName() {
        new Task("SITH002", "This name goes way beyond the twenty character limit", "Over the limit");
    }
    	//tries to use a description longer than 50 characters (should fail)
    @Test(expected = IllegalArgumentException.class)
    public void testTooLongDescription() {
        new Task("JEDI003", "Meditate", "This description is so long that it exceeds the maximum of fifty characters allowed in a task.");
    }
}