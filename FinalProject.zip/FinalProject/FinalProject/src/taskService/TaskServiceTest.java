package taskService;



import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;


public class TaskServiceTest {
	 private TaskService taskService;
	 	//runs before each test to create a new taskService
	    @Before
	    public void setup() {
	        taskService = new TaskService();
	    }
	    //adds a new task and checks if it's stored correctly
	    @Test
	    public void testAddAndRetrieveTask() {
	        Task task = new Task("FORCE001", "Use The Force", "Practice using the Force to move objects");
	        taskService.addTask(task);
	        assertEquals(task, taskService.getTask("FORCE001"));
	    }
	    //adds a new task, then tries to adding another with the same Id (should error)
	    @Test(expected = IllegalArgumentException.class)
	    public void testAddDuplicateId() {
	        Task task1 = new Task("SHIP001", "Fix Falcon", "Repair hyperdrive on Millennium Falcon");
	        Task task2 = new Task("SHIP001", "Fuel Falcon", "Top up fuel cells before takeoff");
	        taskService.addTask(task1);
	        taskService.addTask(task2);  
	    }
	    //Updates task name
	    @Test
	    public void testUpdateName() {
	        Task task = new Task("DROID001", "Build Droid", "Assemble parts for a protocol droid");
	        taskService.addTask(task);
	        taskService.updateTaskName("DROID001", "Repair Droid");
	        assertEquals("Repair Droid", taskService.getTask("DROID001").getName());
	    }
	    //Updates task description 
	    @Test
	    public void testUpdateDescription() {
	        Task task = new Task("MISSION1", "Scout", "Explore nearby asteroid field");
	        taskService.addTask(task);
	        taskService.updateTaskDescription("MISSION1", "Locate Empire's hidden outpost");
	        assertEquals("Locate Empire's hidden outpost", taskService.getTask("MISSION1").getDescription());
	    }

	   //deletes a task and verifes that it is no longer found(should fail)
	    @Test
	    public void testDeleteTask() {
	        Task task = new Task("SITH001", "Infiltrate", "Spy on Darth Vader's ship movements");
	        taskService.addTask(task);
	        taskService.deleteTask("SITH001");
	        assertNull(taskService.getTask("SITH001")); 
	    }
	}